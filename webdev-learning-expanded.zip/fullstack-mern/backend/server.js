const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());
// simple in-memory fallbacks for demo if no Mongo URL provided
const MONGO = process.env.MONGO_URI || '';
if(MONGO){
  mongoose.connect(MONGO).then(()=>console.log('Mongo connected')).catch(e=>console.error('Mongo error',e));
} else {
  console.log('No MONGO_URI provided - backend will run but without DB in this starter');
}
app.get('/api/ping',(req,res)=>res.json({pong:true}));
app.listen(4001, ()=> console.log('MERN backend listening on 4001'));