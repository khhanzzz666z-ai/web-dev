# Landing Premium (Next.js starter)
This folder contains starter files and recommended steps to create a premium landing page using Next.js.

Recommended initialize commands:
1. npx create-next-app@latest landing-premium
2. cd landing-premium
3. npm run dev

Included here: a sample marketing hero component and notes.
