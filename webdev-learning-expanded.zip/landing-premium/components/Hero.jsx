export default function Hero(){ return (
  <section style={{padding: '80px 24px', textAlign:'center'}}>
    <h1>Premium Landing</h1>
    <p>Fast, conversion-focused landing page starter.</p>
    <a href="#cta">Get Started</a>
  </section>
)}