import React from 'react'
export default function App(){
  return (
    <div className="app">
      <aside className="sidebar">
        <h2>Admin</h2>
        <ul><li>Dashboard</li><li>Users</li><li>Settings</li></ul>
      </aside>
      <main className="content">
        <h1>Overview</h1>
        <p>Metrics & charts placeholder</p>
      </main>
    </div>
  )
}