// small interactive touches
document.querySelectorAll('.card').forEach(c=>{
  c.addEventListener('click', ()=> alert('Open project details - this is a starter portfolio'));
});