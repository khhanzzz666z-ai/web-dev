# WebDev Learning — Expanded Pack

Paket ini berisi:
- Portfolio static starter
- Admin dashboard (React + Vite)
- Landing page (Next.js starter notes)
- Full-stack MERN starter
- Dokumentasi dan script autopush ke GitHub

## Next steps
- Sesuaikan konten portfolio
- Tambah fitur autentikasi & database ke dashboard
- Buat Next.js app dari folder landing-premium contoh
- Hubungkan fullstack backend ke MongoDB Atlas dengan MONGO_URI

Lihat /docs/README.md untuk instruksi lebih lengkap.
