# WebDev Learning — Dokumentasi Lengkap

Repository ini berisi beberapa starter projects:
- portfolio-site: static personal portfolio (HTML/CSS/JS)
- dashboard-admin: React admin dashboard starter (Vite)
- landing-premium: Next.js landing page starter notes & component
- fullstack-mern: MERN starter with backend (Express + Mongoose) and frontend (Vite + React)

## Cara memakai
1. Clone repository
2. Buka folder project yang diinginkan, mis. dashboard-admin
3. Jalankan `npm install` lalu `npm run dev`
4. Untuk landing-premium: ikuti petunjuk di /landing-premium/README.md untuk membuat Next.js app

## Struktur dan penjelasan singkat tiap project
- portfolio-site: cocok untuk portofolio cepat, tinggal ganti teks & gambar.
- dashboard-admin: layout admin, perlu integrasi charting (Recharts / Chart.js) & auth.
- landing-premium: gunakan Next.js untuk SEO & performance; disarankan gunakan Tailwind + Vercel untuk deploy.
- fullstack-mern: contoh koneksi ke MongoDB via MONGO_URI env var.

## Deploy singkat
- Frontend statis: host di Netlify / Vercel / GitHub Pages
- Next.js: Vercel (optimal)
- MERN: Deploy backend ke Render / Railway, frontend ke Vercel or Netlify.

## Auto-push ke GitHub (instruksi)
Ada script shell `git_push_instructions.sh` di root yang memuat perintah git untuk inisialisasi repo dan push.
