#!/bin/sh
# Ganti GITHUB_URL dengan url repo yang sudah kamu buat
# Contoh: GITHUB_URL=git@github.com:username/webdev-learning-expanded.git
GITHUB_URL="$1"
if [ -z "$GITHUB_URL" ]; then
  echo "Usage: sh git_push_instructions.sh <GITHUB_URL>"
  exit 1
fi
git init
git add .
git commit -m "Initial commit — webdev learning expanded"
git branch -M main
git remote add origin "$GITHUB_URL"
git push -u origin main
echo "Pushed to $GITHUB_URL"
